# Lights Off
Lights Off es un puzle que se juega en un tablero de 5x5, donde el objetivo es apagar todas las luces. Cada pulsación cambia el estado de la ficha pulsada y sus vecinos no diagonales.

## Reglas
Para completar el puzle Luces fuera, debe apagar todas las luces del tablero. Esto le permitirá pasar al siguiente nivel.
1. El juego comienza con un patrón de luces en un tablero de 5x5.
2. Seleccione una ficha para cambiar su estado y el de sus vecinos no diagonales.
3. Una vez que haya cambiado el estado de todas las luces, habrá completado ese nivel y podrá pasar al siguiente.